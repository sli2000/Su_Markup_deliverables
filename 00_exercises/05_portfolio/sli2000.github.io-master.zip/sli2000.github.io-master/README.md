# Personal Academic Website
This repository contains the source code for my personal academic website, built using the [academicpages](https://github.com/academicpages/academicpages.github.io) Jekyll template.
## Website Link

Visit my live academic website here: [sli2000.github.io](https://sli2000.github.io)
